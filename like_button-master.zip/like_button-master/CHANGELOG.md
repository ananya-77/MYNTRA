## 2.0.5

* Add postFrameCallback to support start animation at first time(#65)

## 2.0.4

* Fix issue that Number reversed when using RTL localization

## 2.0.3

* Fix issue that LikeButtonTapCallback result can't be null

## 2.0.2

* Fix issue that Bubble animation is cropped #50
  
## 2.0.1

* Format dart

## 2.0.0

* Support null-safety
  
## 1.0.4

* Fix animation stop when setstate

## 1.0.3

* Fix readme error

## 1.0.2

* Add stale.yml

## 1.0.1 

* Fix the error of bubbles_painter.dart.
  
## 1.0.0 

* Fix analysis_options
* Breaking change: add likeCount for CountDecoration call back
* Public LikeButtonState and onTap
  
## 0.2.0 

* Support Flutter Web
* Add web demo

## 0.1.9 

* Change postion to CountPostion, support top/bottom
* Add CountDecoration to custom count widget

## 0.1.8 

* Add padding parameter for LikeButton
* Change bubbles' position to make them more clear.

## 0.1.7 

* Feature:
  Add postion(left,right) support for like count widget

## 0.1.6 

* Issue: fix likeCount/isLiked are not updated when rebuild.

## 0.1.4 

* Support to always show like animation and increase like count by setting isLiked to null.

## 0.1.3 

* Clip rect before padding(like count)

## 0.1.2 

* Add OpacityAnimation for LikeCountAnimationType.part

## 0.1.1 

* Update readme
* Change dotSize to bubblesSize

## 0.1.0 

* First Release
