# Size-limit report

```console
npm run size

  Time limit:   80 ms
  Size:         1.04 KB
  Loading time: 21 ms   on slow 3G
  Running time: 54 ms   on Snapdragon 410
  Total time:   75 ms
```

_Thanks to Andrey Sitnik [@ai/size-limit](https://github.com/ai/size-limit)._
