# Developer's build

You will have to clone directly from GitHub and build `goodshare.js` yourself if you want to use the latest dev build.

```console
foo@bar:~$ git clone https://github.com/koddr/goodshare.js.git
foo@bar:~$ cd goodshare.js
foo@bar:goodshare.js$ npm install
foo@bar:goodshare.js$ npm run size
```
