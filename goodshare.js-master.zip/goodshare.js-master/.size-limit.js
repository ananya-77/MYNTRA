module.exports = [
  {
    path: "./src/goodshare.js",
    limit: "80 ms",
  },
];
